sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("proj.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map